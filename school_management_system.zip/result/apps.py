from django.apps import AppConfig


class ResultConfig(AppConfig):
    name = 'result'
